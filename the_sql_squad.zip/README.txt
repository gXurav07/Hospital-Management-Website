cd backend
npm i
npm i -g nodemon
node app.js
cd ../frontend
npm i
npm start
